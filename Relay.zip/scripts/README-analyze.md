# Análisis Inteligente de Correos

Este script analiza los correos procesados y los clasifica automáticamente según su valor e importancia.

## Características

- **Análisis por palabras clave**: Clasificación rápida usando palabras clave predefinidas
- **Análisis con Gemini AI**: Análisis profundo de correos valiosos usando Google Gemini
- **Clasificación automática**: Agrupa correos en categorías:
  - `business_proposal`: Propuestas de negocio, ofertas comerciales
  - `important`: Correos urgentes o importantes
  - `financial`: Temas financieros, pagos, facturas
  - `legal`: Temas legales, contratos, compliance
  - `personal`: Correos personales
  - `technical`: Temas técnicos, implementación
  - `general`: Otros correos
- **Valoración**: Asigna un score de valor (0-100) a cada correo
- **Organización**: Copia correos a carpetas por categoría

## Requisitos

- Node.js 18+
- Google Gemini API Key (opcional, pero recomendado para mejor análisis)
  - Si no está disponible, usa solo análisis por palabras clave

## Configuración

1. Asegúrate de tener tu `.env` configurado con:
   ```env
   GOOGLE_GEMINI_API_KEY=tu_api_key_aqui
   GEMINI_MAX_EMAILS=500  # Opcional: máximo de correos a analizar con Gemini (default: 500)
   ```

2. Los correos deben estar procesados en `processed_emails/`

### Control de Costos

El script está optimizado para minimizar las llamadas a Gemini:
- **Análisis en 2 fases**: Primero analiza todos con palabras clave (gratis), luego solo los mejores con Gemini
- **Límite configurable**: Por defecto solo analiza máximo 500 correos con Gemini
- **Filtrado inteligente**: Solo usa Gemini para correos valiosos (score >= 30) de categorías específicas
- **Pausas automáticas**: Incluye pausas entre lotes para no sobrecargar la API

Puedes ajustar estos valores en el código o mediante variables de entorno.

## Uso

```bash
node scripts/analyze-emails.js
```

## Salida

El script genera:

1. **`email_analysis/analysis_report.json`**: Reporte principal con:
   - Estadísticas generales
   - Top 50 correos más valiosos
   - Top 50 propuestas de negocio
   - Conteo por categoría

2. **`email_analysis/by_category/`**: Carpetas organizadas por categoría:
   - `business_proposal/`: Propuestas de negocio
   - `important/`: Correos importantes
   - `financial/`: Correos financieros
   - `legal/`: Correos legales
   - `personal/`: Correos personales
   - `technical/`: Correos técnicos
   - `general/`: Otros correos
   - `valuable/`: Todos los correos valiosos (score >= 30)

   Cada carpeta contiene:
   - Los archivos `.eml` de esa categoría
   - `report.json` con información detallada

## Ejemplo de Análisis

```json
{
  "category": "business_proposal",
  "valueScore": 75,
  "isValuable": true,
  "isBusinessProposal": true,
  "summary": "Propuesta comercial para...",
  "keyPoints": ["Punto clave 1", "Punto clave 2"]
}
```

## Notas

- El script usa Gemini AI solo para correos valiosos o propuestas de negocio (para optimizar costos)
- Si no hay API key de Gemini, usa solo análisis por palabras clave
- Los correos se copian a las carpetas de categoría, no se mueven (los originales se mantienen)

