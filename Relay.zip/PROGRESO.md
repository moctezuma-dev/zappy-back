# Progreso del Proyecto: Zero‑Click CRM

## Resumen Ejecutivo
Este documento resume los cambios realizados para generar datos mock complejos, sembrarlos en Supabase y exponer una API que permite disparar la generación y el análisis tanto manualmente como automáticamente ante cambios en la base de datos. También lista los pendientes y próximos hitos.

---

## Lo Hecho

### 1) Generación de datos mock
- Generador de Python `correos_mock.py` preparado para producir entidades CRM ampliadas: empresas, departamentos, contactos/usuarios, equipos, tareas/work items, interacciones y señales/noticias (fresh data).
- Salidas existentes en el repositorio: `contactos_mock.json`, `conversaciones_mock.json`, `empresas_mock.json`, `metadatos_mock.json`.

### 2) Esquema de base de datos (Supabase/Postgres)
- Archivo `db/schema.sql` extendido con:
  - Tipos enumerados: `task_status`, `priority_level`, `channel_type`, `person_type`.
  - Tablas: `companies`, `departments`, `teams`, `team_members`, `work_items`, `interactions`, `fresh_data`.
  - Ampliación de `contacts` con `company_id`, tipo de persona (cliente/proveedor/etc.), notas, preferencias y `updated_at`.
  - Índices útiles (por compañía, estado, fechas).

### 3) Seed hacia Supabase
- Script CLI refactorizado: `scripts/seed-supabase.js` ahora reutiliza un servicio compartido `src/services/seeder.js`.
- Funcionalidad actual del seed:
  - Opcionalmente ejecuta `correos_mock.py` (`--generate`).
  - Carga contactos desde `contacts.json` o `contactos_mock.json`.
  - Upsert de `companies` por nombre y creación de departamentos por defecto.
  - Upsert de `contacts` por `email` y enlace de `company_id`.
- Comandos agregados en `package.json`:
  - `npm run seed:usuarios` y `npm run seed:usuarios:generate`.
- Variables de entorno: añadido `SUPABASE_SERVICE_ROLE_KEY` en `.env.example` y soporte en `src/config/env.js`.

### 4) API de administración y análisis
- Nuevas rutas:
  - `POST /api/admin/seed/usuarios` → si `generate = true`, ejecuta Python y luego sube usuarios a Supabase.
  - `POST /api/admin/analyze/trigger` → dispara análisis manual de `interactions`, `work_items`, `contacts` o `fresh_data`.
  - `POST /api/admin/watchers/init` → reinicia suscripciones en tiempo real.
- Servicio de análisis (`src/services/analyzer.js`):
  - Heurística inicial de resumen y sentimiento (simple) para interacciones.
  - Detección de atrasos en `work_items`.
  - Enlace de `contacts.company_id` si falta (por nombre) y actualización de `contacts.sentiment`/`updated_at`.
  - Guarda resultados en la tabla `jobs` con `type: 'analysis'` y `status: 'completed'`.

### 5) Watchers en tiempo real
- Servicio `src/services/realtime.js` suscribe cambios (INSERT/UPDATE) en: `contacts`, `work_items`, `interactions`, `fresh_data`.
- Al producirse cambios, se llama al analizador y se registran resultados en `jobs`.
- Inicialización automática en `src/server.js` al arrancar, si `SUPABASE_SERVICE_ROLE_KEY` está configurada.

---

## Cómo Ejecutarlo

### Preparación
- Configura `.env` con:
  - `SUPABASE_URL`
  - `SUPABASE_SERVICE_ROLE_KEY` (recomendado para watchers y endpoints admin)
  - `SUPABASE_ANON_KEY` (cliente público si se usa desde frontend u otras partes)

### Arranque del servidor
- `npm run dev` (o `npm start`).
- Si el service role está presente, verás: “Suscrito a contacts/work_items/interactions/fresh_data”.

### Sembrar usuarios (CLI)
- `npm run seed:usuarios` → sube desde JSON existente.
- `npm run seed:usuarios:generate` → ejecuta Python y luego sube.

### Sembrar usuarios (API)
- `POST http://localhost:4000/api/admin/seed/usuarios`
  - Body: `{ "generate": true }` para ejecutar `correos_mock.py` antes de subir.

### Disparar análisis manual (API)
- `POST http://localhost:4000/api/admin/analyze/trigger`
  - Body ejemplos:
    - `{ "type": "interactions", "limit": 5 }`
    - `{ "type": "work_items", "id": "<uuid>" }`

### Reiniciar watchers (API)
- `POST http://localhost:4000/api/admin/watchers/init`

---

## Qué Falta por Hacer

### Generación y Seed
- Extender `src/services/seeder.js` para subir además:
  - `work_items` con `status`, `priority`, `budget`, `requirements`, `kpis`, `data`, `due_date` y relaciones (`company_id`, `department_id`, `team_id`, `owner/assignee`).
  - `interactions` con `channel`, `participants`, `budget`, `requirements`, `kpis`, `data`, `notes`, `deadline`, y vínculos.
  - `fresh_data` (noticias/señales) por `company/topic`.
  - `teams` y `team_members` enlazados a `contacts` y `departments`.
- Alinear las salidas de `correos_mock.py` y archivos `*.json` para soportar toda la jerarquía (empresa → departamento → equipo → usuarios → work items/interacciones/señales).

### Ingesta multi‑canal (API)
- Crear endpoints de ingesta:
  - `POST /api/ingest/email|slack|whatsapp|call|video` con normalización a `interactions` y anexos/metadata.
  - Procesamiento de audio/video: extracción/transcripción (via `ffmpeg`/Gemini) y conversión a texto/kpis.

### Análisis avanzado (IA)
- Integrar Gemini para:
  - Resumen preciso por canal, extracción de `requirements`, `kpis`, `next steps`, riesgos.
  - Clasificación (sentimiento, urgencia, tipo de interacción, intent/tema).
  - Generación automática de `work_items` desde “next steps”.
- Pipeline de `jobs` con estados (`pending/processing/completed/failed`) y colas.

### RLS y ownership
- Definir políticas de RLS completas y campos `owner_id`/`user_id` donde aplique.
- Asegurar que el backend (service role) tiene acceso total y el cliente sólo a sus filas.

### Observabilidad
- Logging estructurado (ctx de request, user, entidad afectada).
- Métricas de análisis (tiempo, tasa de éxito, volumen por canal).

### Frontend (si aplica)
- UI para visualizar `interactions`, `work_items` y `fresh_data` con estado/sentimiento.
- Panel de “última interacción por contacto” (vista `latest_interaction_per_contact`).

---

## Próximos Hitos Sugeridos
1. Extender el seed para `work_items`, `interactions`, `fresh_data`, `teams` y `team_members`.
2. Añadir endpoints `/api/ingest/*` y flujo de procesamiento básico (sin IA).
3. Conectar análisis con Gemini y generar `work_items` automáticamente.
4. Definir RLS y ownership; probar con un usuario real.
5. Añadir dashboards simples para validar el modelo.

---

## Archivos Clave Modificados/Agregados
- `scripts/seed-supabase.js` (refactor para usar servicio compartido).
- `src/services/seeder.js` (seed reutilizable para API/CLI).
- `src/config/env.js` (detección de service role).
- `src/services/adminSupabase.js` (cliente Supabase con service role).
- `src/routes/admin.js`, `src/routes/index.js` (rutas admin, registro de router).
- `src/services/analyzer.js` (servicio de análisis básico).
- `src/services/realtime.js` (suscripciones en tiempo real a tablas clave).
- `src/server.js` (inicialización de watchers al arrancar).
- `db/schema.sql` (extensiones de esquema CRM).

---

## Notas
- El análisis actual es heurístico y sirve como “hook” funcional; la mejora con IA está prevista en los pendientes.
- Para evitar errores de RLS, los endpoints y watchers usan `SUPABASE_SERVICE_ROLE_KEY` cuando está disponible.
- Si faltan archivos `contacts.json`/`contactos_mock.json`, el seed con `--generate` ejecuta el generador Python automáticamente.