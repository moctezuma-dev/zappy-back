-- Esquema mínimo sugerido para Supabase/PostgreSQL

create table if not exists public.contacts (
  id uuid primary key default gen_random_uuid(),
  name text,
  company text,
  role text,
  email text unique,
  phone text,
  sentiment text,
  created_at timestamptz default now()
);

create table if not exists public.companies (
  id uuid primary key default gen_random_uuid(),
  name text unique,
  created_at timestamptz default now()
);

create table if not exists public.deals (
  id uuid primary key default gen_random_uuid(),
  title text,
  value numeric,
  currency text,
  stage text,
  contact_id uuid references public.contacts(id),
  created_at timestamptz default now()
);

create table if not exists public.activities (
  id uuid primary key default gen_random_uuid(),
  type text,
  content text,
  contact_id uuid references public.contacts(id),
  created_at timestamptz default now()
);

create table if not exists public.tasks (
  id uuid primary key default gen_random_uuid(),
  title text,
  due_date timestamptz,
  completed boolean default false,
  contact_id uuid references public.contacts(id),
  created_at timestamptz default now()
);

create table if not exists public.jobs (
  id uuid primary key,
  type text not null,
  status text not null,
  input_data jsonb,
  output_data jsonb,
  error text,
  created_at timestamptz default now(),
  completed_at timestamptz
);

-- Nota: Configurar RLS y policies según necesidad.

-- =============================
-- Extensión y Tipos auxiliares
-- =============================
-- Supabase incluye pgcrypto; dejamos el create por si no está.
create extension if not exists pgcrypto;
create extension if not exists vector;

do $$ begin
  create type public.task_status as enum ('pending','in_progress','blocked','completed');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.priority_level as enum ('low','medium','high','critical');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.channel_type as enum ('email','call','meeting','chat','social','web','other');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.person_type as enum ('employee','client','supplier','partner','other');
exception when duplicate_object then null; end $$;

-- =============================
-- Empresas y Departamentos
-- =============================
alter table public.companies
  add column if not exists domain text,
  add column if not exists website text,
  add column if not exists industry text,
  add column if not exists company_type text,
  add column if not exists health_score numeric default 0,
  add column if not exists health_notes text;

create table if not exists public.departments (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  name text not null,
  description text,
  created_at timestamptz default now()
);

-- =============================
-- Equipos
-- =============================
create table if not exists public.teams (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  department_id uuid references public.departments(id) on delete set null,
  name text not null,
  lead_contact_id uuid references public.contacts(id) on delete set null,
  created_at timestamptz default now()
);

create table if not exists public.team_members (
  id uuid primary key default gen_random_uuid(),
  team_id uuid not null references public.teams(id) on delete cascade,
  contact_id uuid not null references public.contacts(id) on delete cascade,
  role text,
  is_lead boolean default false,
  joined_at timestamptz default now(),
  unique(team_id, contact_id)
);

-- =============================
-- Contactos (ampliación para Usuarios del CRM)
-- =============================
alter table public.contacts
  add column if not exists company_id uuid references public.companies(id) on delete set null,
  add column if not exists person_kind public.person_type,
  add column if not exists is_client boolean,
  add column if not exists is_supplier boolean,
  add column if not exists personal_notes text,
  add column if not exists preferences jsonb,
  add column if not exists updated_at timestamptz,
  add column if not exists health_score numeric default 0,
  add column if not exists health_notes text;

create index if not exists contacts_company_id_idx on public.contacts(company_id);
create index if not exists contacts_person_kind_idx on public.contacts(person_kind);

-- =============================
-- Work Items (Tareas/Trabajos/Pendientes)
-- =============================
create table if not exists public.work_items (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  status public.task_status default 'pending',
  priority public.priority_level default 'medium',
  owner_contact_id uuid references public.contacts(id) on delete set null,
  assignee_contact_id uuid references public.contacts(id) on delete set null,
  company_id uuid references public.companies(id) on delete set null,
  department_id uuid references public.departments(id) on delete set null,
  team_id uuid references public.teams(id) on delete set null,
  is_external boolean default false,
  budget numeric,
  currency text default 'USD',
  requirements jsonb,
  kpis jsonb,
  data jsonb,
  due_date timestamptz,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create index if not exists work_items_company_status_idx on public.work_items(company_id, status);
create index if not exists work_items_assignee_idx on public.work_items(assignee_contact_id);
create index if not exists work_items_due_date_idx on public.work_items(due_date);

-- =============================
-- Interacciones
-- =============================
create table if not exists public.interactions (
  id uuid primary key default gen_random_uuid(),
  contact_id uuid references public.contacts(id) on delete set null,
  company_id uuid references public.companies(id) on delete set null,
  department_id uuid references public.departments(id) on delete set null,
  channel public.channel_type,
  occurred_at timestamptz not null,
  participants jsonb, -- lista libre (puede contener ids de contactos si aplica)
  budget numeric,
  currency text,
  requirements jsonb,
  kpis jsonb,
  data jsonb,
  notes text,
  deadline timestamptz,
  created_at timestamptz default now()
);

create index if not exists interactions_company_time_idx on public.interactions(company_id, occurred_at desc);
create index if not exists interactions_contact_time_idx on public.interactions(contact_id, occurred_at desc);

-- Vista útil: última interacción por contacto
create or replace view public.latest_interaction_per_contact as
select i.contact_id,
       max(i.occurred_at) as last_interaction_at
from public.interactions i
group by i.contact_id;

-- =============================
-- Data Fresh Collector (Noticias/Señales)
-- =============================
create table if not exists public.fresh_data (
  id uuid primary key default gen_random_uuid(),
  company_id uuid references public.companies(id) on delete set null,
  topic text,
  source text,
  source_url text,
  title text,
  summary text,
  tags jsonb,
  published_at timestamptz,
  detected_at timestamptz default now()
);

create index if not exists fresh_data_company_published_idx on public.fresh_data(company_id, published_at desc);
create index if not exists fresh_data_topic_idx on public.fresh_data(topic);

-- =============================
-- Knowledge Base
-- =============================
create table if not exists public.knowledge_entries (
  id uuid primary key default gen_random_uuid(),
  company_id uuid references public.companies(id) on delete cascade,
  title text,
  content text not null,
  embedding vector(1536),
  metadata jsonb,
  created_at timestamptz default now()
);

create index if not exists knowledge_entries_company_idx on public.knowledge_entries(company_id);
create index if not exists knowledge_entries_created_idx on public.knowledge_entries(created_at desc);

-- =============================
-- IA / Contextos Semánticos
-- =============================
create table if not exists public.ai_contexts (
  id uuid primary key default gen_random_uuid(),
  type text not null,
  source_id uuid not null,
  company_id uuid references public.companies(id) on delete set null,
  contact_id uuid references public.contacts(id) on delete set null,
  text text not null,
  embedding vector(1536),
  metadata jsonb,
  created_at timestamptz default now(),
  updated_at timestamptz default now(),
  unique(type, source_id)
);

create index if not exists ai_contexts_company_idx on public.ai_contexts(company_id);
create index if not exists ai_contexts_contact_idx on public.ai_contexts(contact_id);
create index if not exists ai_contexts_type_idx on public.ai_contexts(type);

create or replace function public.match_ai_contexts(
  query_embedding vector(1536),
  match_count int default 10,
  filter_type text default null,
  filter_company uuid default null,
  filter_contact uuid default null
)
returns table (
  id uuid,
  type text,
  source_id uuid,
  company_id uuid,
  contact_id uuid,
  text text,
  metadata jsonb,
  similarity double precision,
  created_at timestamptz,
  updated_at timestamptz
)
language sql
stable
as $$
  select
    ac.id,
    ac.type,
    ac.source_id,
    ac.company_id,
    ac.contact_id,
    ac.text,
    ac.metadata,
    1 - (ac.embedding <=> query_embedding) as similarity,
    ac.created_at,
    ac.updated_at
  from public.ai_contexts ac
  where (filter_type is null or ac.type = filter_type)
    and (filter_company is null or ac.company_id = filter_company)
    and (filter_contact is null or ac.contact_id = filter_contact)
  order by ac.embedding <=> query_embedding
  limit match_count;
$$;

-- =============================
-- IA / Sesiones de Chat
-- =============================
create table if not exists public.ai_sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid,
  company_id uuid references public.companies(id) on delete set null,
  title text,
  created_at timestamptz default now()
);

create table if not exists public.ai_messages (
  id uuid primary key default gen_random_uuid(),
  session_id uuid not null references public.ai_sessions(id) on delete cascade,
  role text not null check (role in ('system','user','assistant')),
  content text not null,
  context jsonb,
  created_at timestamptz default now()
);

create table if not exists public.ai_tool_calls (
  id uuid primary key default gen_random_uuid(),
  message_id uuid not null references public.ai_messages(id) on delete cascade,
  tool_name text,
  input jsonb,
  output jsonb,
  created_at timestamptz default now()
);

create index if not exists ai_messages_session_idx on public.ai_messages(session_id, created_at);
create index if not exists ai_sessions_company_idx on public.ai_sessions(company_id);

-- =============================
-- Alertas
-- =============================
create table if not exists public.alerts (
  id uuid primary key default gen_random_uuid(),
  entity_type text not null,
  entity_id uuid not null,
  company_id uuid references public.companies(id) on delete cascade,
  contact_id uuid references public.contacts(id) on delete set null,
  severity text not null default 'medium',
  status text not null default 'open',
  message text,
  data jsonb,
  created_at timestamptz default now(),
  updated_at timestamptz default now(),
  resolved_at timestamptz
);

create index if not exists alerts_company_idx on public.alerts(company_id);
create index if not exists alerts_contact_idx on public.alerts(contact_id);
create index if not exists alerts_status_idx on public.alerts(status);
create index if not exists alerts_severity_idx on public.alerts(severity);
create unique index if not exists alerts_entity_open_unique
  on public.alerts(entity_type, entity_id)
  where status = 'open';

-- =============================
-- Dashboard / Insights
-- =============================
create or replace function public.dashboard_summary(p_company uuid default null)
returns json
language sql
stable
as $$
with filtered_interactions as (
  select *
  from public.interactions
  where p_company is null or company_id = p_company
),
filtered_work_items as (
  select *
  from public.work_items
  where p_company is null or company_id = p_company
),
filtered_fresh as (
  select *
  from public.fresh_data
  where p_company is null or company_id = p_company
),
filtered_contacts as (
  select *
  from public.contacts
  where p_company is null or company_id = p_company
)
select json_build_object(
  'interactions', json_build_object(
    'total', (select count(*) from filtered_interactions),
    'last7Days', (select count(*) from filtered_interactions where occurred_at >= now() - interval '7 days'),
    'last30Days', (select count(*) from filtered_interactions where occurred_at >= now() - interval '30 days'),
    'uniqueContacts', (select count(distinct contact_id) from filtered_interactions where contact_id is not null)
  ),
  'workItems', json_build_object(
    'total', (select count(*) from filtered_work_items),
    'open', (select count(*) from filtered_work_items where status <> 'completed'),
    'overdue', (
      select count(*)
      from filtered_work_items
      where status <> 'completed'
        and due_date is not null
        and due_date < now()
    ),
    'dueNext7Days', (
      select count(*)
      from filtered_work_items
      where status <> 'completed'
        and due_date is not null
        and due_date between now() and now() + interval '7 days'
    )
  ),
  'freshData', json_build_object(
    'total', (select count(*) from filtered_fresh),
    'last30Days', (select count(*) from filtered_fresh where detected_at >= now() - interval '30 days')
  ),
  'contacts', json_build_object(
    'total', (select count(*) from filtered_contacts),
    'updatedLast30Days', (
      select count(*)
      from filtered_contacts
      where updated_at is not null
        and updated_at >= now() - interval '30 days'
    )
  ),
  'pipeline', json_build_object(
    'totalBudget', (
      select coalesce(sum(budget), 0)
      from filtered_interactions
      where budget is not null
    ),
    'avgBudget', (
      select coalesce(avg(budget), 0)
      from filtered_interactions
      where budget is not null
    )
  )
);
$$;

create or replace function public.work_items_status_breakdown(p_company uuid default null)
returns table(status public.task_status, total bigint)
language sql
stable
as $$
  select status, count(*)::bigint as total
  from public.work_items
  where p_company is null or company_id = p_company
  group by status
  order by status;
$$;

create or replace function public.sentiment_breakdown(p_company uuid default null)
returns table(sentiment text, total bigint)
language sql
stable
as $$
  select coalesce(sentiment, 'unknown') as sentiment, count(*)::bigint as total
  from public.contacts
  where p_company is null or company_id = p_company
  group by coalesce(sentiment, 'unknown')
  order by total desc;
$$;

-- =============================
-- Insights / Tendencias
-- =============================
create or replace function public.interactions_trend(p_company uuid default null, p_days int default 30)
returns table(day date, total bigint, with_budget bigint)
language sql
stable
as $$
  with series as (
    select generate_series::date as day
    from generate_series(current_date - (p_days - 1), current_date, interval '1 day')
  ),
  data as (
    select date(occurred_at) as day,
           count(*)::bigint as total,
           count(*) filter (where budget is not null)::bigint as with_budget
    from public.interactions
    where occurred_at >= current_date - (p_days || ' days')::interval
      and (p_company is null or company_id = p_company)
    group by date(occurred_at)
  )
  select s.day,
         coalesce(d.total, 0)::bigint as total,
         coalesce(d.with_budget, 0)::bigint as with_budget
  from series s
  left join data d on s.day = d.day
  order by s.day;
$$;

create or replace function public.work_items_trend(p_company uuid default null, p_days int default 30)
returns table(day date, created bigint, completed bigint)
language sql
stable
as $$
  with series as (
    select generate_series::date as day
    from generate_series(current_date - (p_days - 1), current_date, interval '1 day')
  ),
  created_data as (
    select date(created_at) as day, count(*)::bigint as total
    from public.work_items
    where created_at >= current_date - (p_days || ' days')::interval
      and (p_company is null or company_id = p_company)
    group by date(created_at)
  ),
  completed_data as (
    select date(updated_at) as day, count(*)::bigint as total
    from public.work_items
    where updated_at >= current_date - (p_days || ' days')::interval
      and status = 'completed'
      and (p_company is null or company_id = p_company)
    group by date(updated_at)
  )
  select s.day,
         coalesce(c.total, 0)::bigint as created,
         coalesce(f.total, 0)::bigint as completed
  from series s
  left join created_data c on s.day = c.day
  left join completed_data f on s.day = f.day
  order by s.day;
$$;

create or replace function public.fresh_data_trend(p_company uuid default null, p_days int default 30)
returns table(day date, total bigint)
language sql
stable
as $$
  with series as (
    select generate_series::date as day
    from generate_series(current_date - (p_days - 1), current_date, interval '1 day')
  ),
  data as (
    select date(detected_at) as day, count(*)::bigint as total
    from public.fresh_data
    where detected_at >= current_date - (p_days || ' days')::interval
      and (p_company is null or company_id = p_company)
    group by date(detected_at)
  )
  select s.day, coalesce(d.total, 0)::bigint as total
  from series s
  left join data d on s.day = d.day
  order by s.day;
$$;

create or replace function public.actionable_insights(p_company uuid default null)
returns json
language sql
stable
as $$
with contact_activity as (
  select
    c.id,
    c.name,
    c.email,
    c.sentiment,
    c.updated_at,
    c.company_id,
    max(i.occurred_at) as last_interaction_at
  from public.contacts c
  left join public.interactions i on i.contact_id = c.id
  group by c.id
),
risky_contacts as (
  select
    ca.id,
    ca.name,
    ca.email,
    ca.sentiment,
    ca.last_interaction_at,
    ca.company_id,
    comp.name as company_name
  from contact_activity ca
  left join public.companies comp on comp.id = ca.company_id
  where (p_company is null or ca.company_id = p_company)
    and (
      coalesce(ca.sentiment, 'neutral') = 'negative'
      or ca.last_interaction_at is null
      or ca.last_interaction_at < now() - interval '14 days'
    )
  order by ca.last_interaction_at nulls first
  limit 20
),
open_alerts as (
  select
    a.id,
    a.entity_type,
    a.entity_id,
    a.severity,
    a.message,
    a.company_id,
    comp.name as company_name,
    coalesce(i.contact_id, w.assignee_contact_id, a.contact_id) as contact_id,
    coalesce(ic.name, wc.name) as contact_name,
    a.created_at
  from public.alerts a
  left join public.companies comp on comp.id = a.company_id
  left join public.interactions i on a.entity_type = 'interaction' and a.entity_id = i.id
  left join public.work_items w on a.entity_type = 'work_item' and a.entity_id = w.id
  left join public.contacts ic on ic.id = i.contact_id
  left join public.contacts wc on wc.id = w.assignee_contact_id
  where a.status = 'open'
    and (p_company is null or a.company_id = p_company)
  order by a.created_at desc
  limit 20
),
overdue_work as (
  select
    w.id,
    w.title,
    w.priority,
    w.due_date,
    w.company_id,
    comp.name as company_name,
    w.assignee_contact_id,
    assignee.name as assignee_name
  from public.work_items w
  left join public.companies comp on comp.id = w.company_id
  left join public.contacts assignee on assignee.id = w.assignee_contact_id
  where w.status <> 'completed'
    and w.due_date is not null
    and w.due_date < now()
    and (p_company is null or w.company_id = p_company)
  order by w.due_date asc
  limit 20
),
stale_companies as (
  select
    comp.id,
    comp.name,
    comp.industry,
    max(i.occurred_at) as last_interaction_at,
    count(distinct i.id) filter (where i.occurred_at >= now() - interval '30 days') as interactions_last30,
    count(distinct w.id) filter (where w.status <> 'completed') as open_work_items
  from public.companies comp
  left join public.interactions i on i.company_id = comp.id
  left join public.work_items w on w.company_id = comp.id
  where p_company is null or comp.id = p_company
  group by comp.id
  having max(i.occurred_at) is null or max(i.occurred_at) < now() - interval '21 days'
  order by max(i.occurred_at) nulls first
  limit 20
)
select json_build_object(
  'risky_contacts', coalesce(json_agg(json_build_object(
    'id', rc.id,
    'name', rc.name,
    'email', rc.email,
    'sentiment', rc.sentiment,
    'last_interaction_at', rc.last_interaction_at,
    'company_id', rc.company_id,
    'company_name', rc.company_name
  ) order by rc.last_interaction_at nulls first), '[]'::json),
  'open_alerts', coalesce(json_agg(json_build_object(
    'id', oa.id,
    'entity_type', oa.entity_type,
    'entity_id', oa.entity_id,
    'severity', oa.severity,
    'message', oa.message,
    'company_id', oa.company_id,
    'company_name', oa.company_name,
    'contact_id', oa.contact_id,
    'contact_name', oa.contact_name,
    'created_at', oa.created_at
  ) order by oa.created_at desc), '[]'::json),
  'overdue_work_items', coalesce(json_agg(json_build_object(
    'id', ow.id,
    'title', ow.title,
    'priority', ow.priority,
    'due_date', ow.due_date,
    'company_id', ow.company_id,
    'company_name', ow.company_name,
    'assignee_contact_id', ow.assignee_contact_id,
    'assignee_name', ow.assignee_name
  ) order by ow.due_date asc), '[]'::json),
  'stale_companies', coalesce(json_agg(json_build_object(
    'id', sc.id,
    'name', sc.name,
    'industry', sc.industry,
    'last_interaction_at', sc.last_interaction_at,
    'interactions_last30', sc.interactions_last30,
    'open_work_items', sc.open_work_items
  ) order by sc.last_interaction_at nulls first), '[]'::json)
)
from risky_contacts rc
full join open_alerts oa on false
full join overdue_work ow on false
full join stale_companies sc on false;
$$;

-- =============================
-- Notas
-- =============================
-- - Este esquema amplía el mínimo existente sin romper tablas previas.
-- - Puede migrarse gradualmente; los endpoints actuales que usan 'contacts' siguen válidos.
-- - Ajustar RLS según roles y visibilidad requerida.