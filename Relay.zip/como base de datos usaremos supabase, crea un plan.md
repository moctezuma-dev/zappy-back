# Product Requirements Document (PRD) - ACTUALIZADO
## Zero-Click CRM: Voice & AI-Powered Customer Relationship System

***

## 1. Visión y propuesta de valor

**Zero-Click CRM** es un sistema revolucionario de gestión de relaciones con clientes que elimina completamente la entrada manual de datos mediante automatización total con inteligencia artificial. El usuario solo conversa naturalmente con sus clientes a través de cualquier canal (email, llamadas, WhatsApp), y el CRM se actualiza automáticamente sin clicks, formularios ni campos por llenar.

**Problema**: Profesionales dedican 30-40% de su tiempo actualizando CRM manualmente, resultando en datos desactualizados, incompletos e inconsistentes.

**Solución**: CRM inteligente que escucha, lee y aprende de cada interacción, extrayendo información relevante y actualizando registros sin intervención humana.

***

## 2. Requerimientos técnicos obligatorios

### 2.1 Stack tecnológico

- **Backend**: Node.js + Express.js
- **Base de datos**: Supabase (PostgreSQL con Row Level Security)
- **IA**: Google Gemini 1.5 Pro API (multimodal) - Acceso directo via API key
- **Cloud**: Google Cloud Platform para infraestructura complementaria
- **Almacenamiento**: Google Cloud Storage (opcional) o solución alternativa
- **Autenticación**: Supabase Auth + OAuth 2.0

### 2.2 API de Google Gemini 1.5 Pro

**Modelo utilizado**: `gemini-1.5-pro-002` o `gemini-1.5-pro-latest`

**Acceso a la API**:
- API Key obtenida desde Google AI Studio (ai.google.dev)
- SDK oficial: `@google/generative-ai` para Node.js
- Endpoint directo: `https://generativelanguage.googleapis.com/v1beta/models/`
- Sin necesidad de Vertex AI ni configuración compleja de GCP

**Capacidades multimodales utilizadas**:
- **Audio**: procesamiento nativo de archivos wav, mp3, m4a, aac
- **Texto**: análisis de emails, mensajes, documentos
- **Imágenes**: extracción de información de capturas, tarjetas de negocio
- **Video**: análisis de grabaciones de reuniones (futuro)

**Características clave aprovechadas**:
- **Ventana de contexto**: 2M+ tokens (equivalente a ~107 horas de audio)
- **Structured output**: generación JSON con schema predefinido
- **Function calling**: capacidad de invocar funciones CRM automáticamente
- **Multimodal nativo**: procesar audio + texto simultáneamente sin servicios separados
- **Diarización incluida**: identificación de hablantes sin herramientas adicionales

**Límites y consideraciones**:
- Rate limits: 1000 requests por minuto (tier gratuito)
- Tamaño máximo de audio: 9.5 horas de duración
- Tiempo de procesamiento: variable según carga de la API
- Costo: tier gratuito generoso para MVP, escala según pricing de Google

***

## 3. Características principales del producto

### 3.1 AI Auto-Populating CRM (Autollenado inteligente)

**Descripción**: Sistema que lee automáticamente correos electrónicos, transcripciones de llamadas y notas de voz de WhatsApp, extrayendo campos clave sin intervención manual mediante la API de Gemini 1.5 Pro multimodal.

**Campos extraídos automáticamente por Gemini**:
- **Nombre de contacto**: identificación completa de la persona
- **Empresa**: nombre de la organización asociada
- **Cargo/Posición**: título profesional del contacto
- **Email y teléfono**: datos de contacto normalizados
- **Siguiente paso**: acción acordada o pendiente inferida
- **Valor del trato**: monto monetario mencionado con moneda
- **Fecha de seguimiento**: timestamp de próxima interacción
- **Notas contextuales**: resumen ejecutivo generado por IA
- **Sentimiento**: clasificación emocional (positivo, neutral, negativo)
- **Temas clave**: topics principales extraídos
- **Urgencia/Prioridad**: nivel de importancia inferido del lenguaje

**Fuentes de datos procesadas**:
- Emails entrantes y salientes via Gmail API
- Mensajes de texto y audios de WhatsApp Business API
- Llamadas telefónicas grabadas (archivos subidos)
- Notas de voz dictadas por el usuario
- Transcripciones de reuniones de Zoom/Meet
- Mensajes de Slack (fase 2)

**Implementación con Gemini API**:
- Llamadas directas a `generateContent()` del SDK
- Prompts estructurados con instrucciones específicas de extracción
- Response schema JSON para garantizar formato consistente
- Manejo de errores y reintentos automáticos
- Procesamiento asíncrono mediante queue en base de datos

**Precisión esperada**: >85% en extracción de campos críticos (nombre, email, empresa), >80% en análisis de sentimiento y próximos pasos.

### 3.2 Voice-to-Structured-CRM Model (Voz a CRM estructurado)

**Descripción**: Procesamiento de audio mediante Gemini 1.5 Pro multimodal que transforma notas de voz o llamadas grabadas en registros CRM estructurados, eliminando completamente la necesidad de escritura manual.

**Capacidades aprovechadas de Gemini multimodal**:
- **Transcripción automática**: conversión nativa de audio a texto sin Speech-to-Text separado
- **Diarización de hablantes**: identificación automática de quién habla (usuario vs cliente)
- **Comprensión contextual**: análisis simultáneo de voz, tono, intención y sentimiento
- **Extracción de entidades**: nombres, empresas, fechas, montos extraídos del audio
- **Normalización automática**: formatos estandarizados (fechas ISO, monedas, teléfonos)
- **Soporte multilenguaje**: español e inglés detectados automáticamente

**Flujo de procesamiento con Gemini API**:
1. Usuario sube archivo de audio o graba directamente en app
2. Frontend envía audio a backend como base64 o multipart/form-data
3. Backend crea job asíncrono en Supabase con estado "pending"
4. Backend construye prompt para Gemini con instrucciones de extracción
5. Backend incluye audio como `inlineData` o via URI si está en Cloud Storage
6. Gemini API recibe audio + prompt multimodal
7. Gemini procesa audio completo (hasta 9.5 horas soportadas)
8. Gemini aplica diarización y transcribe contenido
9. Gemini extrae entidades según response schema definido
10. API devuelve JSON estructurado con todos los campos CRM
11. Backend parsea respuesta y valida campos requeridos
12. Backend crea/actualiza contacto en Supabase
13. Backend genera actividad de tipo "call" con transcripción
14. Si deal mencionado, backend crea oportunidad con monto
15. Próximos pasos se convierten en tareas con fechas
16. Job actualizado a "completed" con output_data
17. Usuario recibe notificación vía Supabase Realtime

**Formato de audio soportado**:
- WAV, MP3, M4A, AAC, OGG
- Duración: hasta 9.5 horas por archivo
- Calidad recomendada: 16kHz+ para mejor precisión

**Tiempo de procesamiento estimado**:
- Audio de 5 minutos: ~30-45 segundos
- Audio de 15 minutos: ~45-60 segundos
- Audio de 1 hora: ~90-120 segundos
- Variable según carga de la API de Google

**Ventajas del enfoque multimodal de Gemini**:
- Un solo modelo para transcripción + análisis (no necesitas Whisper + GPT)
- Diarización incluida sin servicios adicionales
- Comprensión contextual superior al procesar audio directamente
- Menor latencia al eliminar pasos intermedios
- Costo reducido al consolidar servicios

### 3.3 Data Freshness Engine (Motor de frescura de datos)

**Descripción**: Sistema proactivo que mantiene los datos del CRM actualizados monitoreando continuamente múltiples fuentes de información sin intervención del usuario, procesando actualizaciones con Gemini API.

**Fuentes monitoreadas en tiempo real**:

**Correos electrónicos**:
- Gmail push notifications via webhooks
- Procesamiento automático con Gemini de cada email entrante
- Gemini extrae cambios en información de contacto
- Detección de nuevos proyectos o cambios de empresa mencionados
- Actualización automática de "última interacción"

**Invitaciones y eventos de calendario**:
- Google Calendar push notifications o polling periódico
- Gemini analiza descripciones de eventos para extraer contexto
- Identificación de participantes y temas a discutir
- Generación automática de actividades tipo "meeting"
- Alertas de reuniones próximas con contexto preparado

**Perfiles de LinkedIn** (fase 2):
- Scraping periódico de perfiles conectados
- Gemini analiza cambios en biografía y experiencia
- Detección automática de cambios de empleo o cargo
- Actualización de metadata de contacto
- Alertas cuando contacto clave cambia de rol

**Sitios web de compañías** (fase 2):
- Monitoreo mensual de páginas corporativas
- Gemini extrae cambios en equipo, productos, noticias
- Detección de eventos importantes (funding, expansiones)
- Enriquecimiento automático de perfil de empresa

**Lógica de actualización inteligente**:
- Gemini decide qué campos actualizar basado en confianza de la información
- Prevención de sobrescritura de datos manualmente corregidos
- Audit log de cambios automáticos en metadata
- Usuario puede revisar y revertir cambios si es necesario

**Frecuencia de sincronización**:
- Emails: tiempo real (<1 min desde recepción)
- Calendar: cada 15 minutos + push notifications
- LinkedIn/Web: diario o semanal según relevancia

### 3.4 AI Search and Relationship Insights (Búsqueda inteligente e insights)

**Descripción**: Motor de búsqueda conversacional powered by Gemini que permite consultas en lenguaje natural y genera insights proactivos sobre el estado de relaciones con clientes.

**Búsqueda semántica con Gemini API**:

**Proceso de consulta**:
1. Usuario escribe o habla pregunta en lenguaje natural
2. Si es voz, audio se envía primero a Gemini para transcripción
3. Backend recupera datos relevantes de Supabase (últimos 50-100 registros)
4. Backend construye contexto con datos del CRM en formato estructurado
5. Backend envía prompt a Gemini: contexto + pregunta del usuario
6. Gemini analiza datos y genera respuesta conversacional
7. Gemini identifica entidades relevantes (IDs de contactos, deals)
8. Backend parsea respuesta y recupera entidades completas
9. Frontend muestra respuesta + cards visuales clickeables

**Ejemplos de consultas soportadas**:
- "Muéstrame todas las conversaciones con CTOs en el último mes"
- "¿Cuáles deals están en riesgo por falta de respuesta en 14 días?"
- "¿Quiénes son mis contactos en la industria de tecnología?"
- "¿Cuándo fue mi última reunión con Juan Pérez?"
- "Deals mayores a $50K en etapa de negociación"
- "Contactos que mencionaron 'presupuesto' esta semana"
- "Clientes con sentimiento negativo en últimas interacciones"
- "Empresas con las que no he hablado en 60+ días"

**Insights automáticos generados por Gemini**:

**Análisis proactivo diario/semanal**:
- Backend envía resumen de actividad reciente a Gemini
- Gemini identifica patrones, riesgos y oportunidades
- Generación de reporte ejecutivo con recomendaciones
- Alertas específicas enviadas al usuario

**Deals en riesgo detectados**:
- Oportunidades sin actividad reciente (>14 días)
- Deals con fecha de cierre próxima sin avance de etapa
- Conversaciones con sentimiento negativo
- Contactos que no responden después de múltiples intentos

**Oportunidades identificadas**:
- Contactos que mencionaron expansión o nuevos proyectos
- Clientes satisfechos candidatos para upselling
- Referencias potenciales basadas en relación positiva
- Momentos óptimos para contactar según patrones

**Patrones de comportamiento analizados**:
- Mejor día/hora para contactar a cada persona
- Tiempo promedio de respuesta por contacto
- Ciclo de ventas promedio por industria
- Canales preferidos de comunicación

**Implementación técnica con Gemini**:
- Prompts especializados para cada tipo de insight
- Function calling para que Gemini sugiera acciones específicas
- Structured output con secciones: resumen, riesgos, oportunidades, acciones
- Caché de insights generados para reducir llamadas a API

### 3.5 Zero-Click CRM Interface (Interfaz sin fricción)

**Descripción**: Diseño de experiencia de usuario donde emails, mensajes de voz y datos de llamadas ingresan al sistema con interacción mínima, sin formularios ni registros manuales.

**Principios de diseño zero-click**:

**Entrada de datos invisible**:
- Emails se procesan automáticamente al llegar (usuario no hace nada)
- WhatsApp se integra via webhook (mensajes fluyen sin intervención)
- Audios se suben con 1 click de "Procesar llamada" o drag & drop
- Sistema infiere toda la información desde contenido original
- No hay formularios con campos vacíos esperando ser llenados

**Dashboard minimalista enfocado en consumo**:
- Vista principal: timeline de actividades recientes auto-generadas
- Cards de contactos con badge de "actualizado hoy" por procesamiento IA
- Pipeline de deals con etapas visuales (drag & drop opcional)
- Barra de búsqueda conversacional siempre visible y prominente
- Botón flotante de "Grabar audio" accesible desde cualquier pantalla

**Estados de procesamiento transparentes**:
- Indicador visual cuando Gemini está procesando audio/email
- Progress estimado: "Analizando llamada... 45 segundos restantes"
- Notificación toast al completar: "Llamada procesada ✓ Nuevo contacto: María"
- Badge de "procesando" en jobs pendientes
- Historial de procesamiento accesible para debugging

**Notificaciones inteligentes no intrusivas**:
- Toast notifications cuando procesamiento completa exitosamente
- Badges numéricos en contactos/deals actualizados recientemente
- Alertas push solo para eventos críticos (deals en riesgo, urgencias)
- Sin interrupciones durante flujo de trabajo activo del usuario

**Acciones contextuales un-click**:
- Click en contacto → perfil completo + timeline + transcripciones
- Click en deal → detalle con monto, etapa, tareas, historial
- Click en actividad → transcripción completa con highlighting
- Botón "Contexto completo" invoca búsqueda semántica sobre entidad

**Mobile-first para grabación en campo**:
- App optimizada para grabar/subir audios desde teléfono
- Botón de grabación grande y accesible con un thumb
- Procesamiento offline (queue local, sync al reconectar)
- Notificaciones push cuando CRM se actualiza remotamente
- Vista "Hoy" con próximas tareas y recordatorios

**Flujos diseñados para zero-click**:

**Flujo ideal de llamada (0 clicks manuales)**:
1. Usuario termina llamada con cliente
2. Sistema detecta grabación de llamada del teléfono (integración futura)
3. Audio se sube automáticamente en background
4. Usuario ve notificación: "Procesando llamada con Cliente..."
5. 60 segundos después: "Llamada procesada ✓"
6. Usuario abre app y todo está actualizado sin haber tocado nada

**Flujo práctico MVP (2 clicks)**:
1. Usuario termina llamada
2. Abre app y toca botón "Procesar última llamada" (1 click)
3. Selecciona archivo de grabación (1 click)
4. Sistema procesa automáticamente
5. Dashboard se actualiza solo

**Flujo de email (0 clicks - totalmente automático)**:
1. Cliente envía email
2. Gmail webhook notifica al backend
3. Gemini procesa email automáticamente
4. CRM se actualiza en background
5. Usuario recibe notificación pasiva "Email de [Cliente] procesado"
6. Usuario revisa cuando tiene tiempo, información ya está

**Flujo de búsqueda (1 click o comando de voz)**:
1. Usuario toca micrófono o escribe pregunta
2. Dice/escribe: "¿Cuándo hablé con Ana?"
3. Respuesta aparece en <3 segundos
4. Cards muestran contacto y actividades relacionadas
5. Usuario puede explorar más con clicks adicionales opcionales

***

## 4. Integración técnica con Gemini 1.5 Pro API

### 4.1 Configuración y autenticación

**Obtención de API Key**:
- Crear cuenta en Google AI Studio (ai.google.dev)
- Generar API key desde dashboard
- Almacenar key en variables de entorno (nunca en código)
- Variable: `GOOGLE_GEMINI_API_KEY`

**Instalación del SDK**:
- Package: `@google/generative-ai` (versión latest)
- Instalación: `npm install @google/generative-ai`
- Inicialización en backend con API key

**Rate limits y cuotas**:
- Tier gratuito: 15 requests por minuto, 1500 requests por día
- Tier pago: 1000 requests por minuto, configurable
- Manejo de throttling con retry exponencial
- Queue de requests si se excede límite

### 4.2 Procesamiento de audio multimodal

**Formato de entrada de audio**:
- Audio como base64 string en `inlineData`
- O referencia a archivo en Cloud Storage via URI
- MimeType explícito: audio/wav, audio/mp3, audio/m4a

**Construcción de prompt para audio**:
```
Analiza esta grabación de llamada de ventas y extrae:
1. Transcripción completa identificando quién habla
2. Información del contacto cliente (nombre, empresa, email, teléfono)
3. Detalles de oportunidad de negocio si se menciona (título, monto, etapa)
4. Próximos pasos o compromisos acordados con fechas
5. Sentimiento general de la conversación
6. Temas clave discutidos

Devuelve la información en formato JSON estructurado.
```

**Response schema para structured output**:
- Definir schema JSON con tipos de datos esperados
- Campos requeridos vs opcionales
- Enums para valores categóricos (sentimiento, etapa)
- Arrays para listas (próximos pasos, temas)

**Manejo de respuesta**:
- Parse JSON automático si usas `responseMimeType: "application/json"`
- Validación de campos requeridos
- Fallback para campos faltantes
- Logging de errores de parsing

### 4.3 Procesamiento de texto (emails, mensajes)

**Construcción de prompt para emails**:
```
Analiza este email y extrae información relevante para un CRM:

From: {email.from}
Subject: {email.subject}
Body:
{email.body}

Extrae:
- Información del remitente (nombre, empresa, cargo)
- Intención del mensaje
- Oportunidades de negocio mencionadas
- Próximos pasos o compromisos
- Sentimiento del mensaje
- Resumen ejecutivo (2-3 oraciones)

Formato de salida: JSON estructurado
```

**Optimización de prompts**:
- Instrucciones claras y específicas
- Ejemplos de salida esperada (few-shot learning)
- Formato de salida explícito
- Manejo de casos edge ("si no hay deal mencionado, devuelve null")

### 4.4 Function calling para automatización

**Declaración de funciones CRM**:
- `create_contact`: crear/actualizar contacto con parámetros
- `create_deal`: crear oportunidad de negocio
- `create_task`: crear tarea o recordatorio
- `update_contact_sentiment`: actualizar sentimiento de relación

**Flujo de function calling**:
1. Gemini recibe audio/texto + declaraciones de funciones disponibles
2. Gemini decide qué funciones invocar basado en contenido
3. Gemini extrae parámetros necesarios del contexto
4. API devuelve `functionCall` con nombre y argumentos
5. Backend ejecuta función real en Supabase
6. Backend devuelve resultado a Gemini
7. Gemini puede hacer llamadas adicionales si es necesario
8. Gemini genera respuesta final confirmando acciones tomadas

**Ventajas del function calling**:
- Gemini decide automáticamente qué acciones tomar
- Reduce lógica de negocio custom en backend
- Permite flujos complejos multi-paso
- Sistema puede evolucionar agregando nuevas funciones

### 4.5 Búsqueda semántica con contexto

**Preparación de contexto para Gemini**:
- Recuperar datos relevantes de Supabase (últimos N registros)
- Formatear en JSON o texto estructurado
- Incluir relaciones (contacto → empresa → deals)
- Limitar tamaño de contexto a ~100K tokens

**Prompt de búsqueda**:
```
Eres un asistente de CRM inteligente. Tienes acceso a los siguientes datos:

Contactos:
{JSON de contactos}

Deals:
{JSON de deals}

Actividades recientes:
{JSON de actividades}

El usuario pregunta: "{query}"

Responde de forma clara y directa, identifica las entidades relevantes (contactos, deals) por ID, ofrece insights sobre la situación y sugiere acciones recomendadas si aplica.
```

**Optimización de búsquedas**:
- Caché de contexto para queries similares
- Filtrado previo en SQL para reducir datos enviados
- Embeddings para búsqueda semántica avanzada (fase 2)
- Historial de conversación para búsquedas follow-up

### 4.6 Manejo de errores y reintentos

**Errores comunes de la API**:
- 429 Too Many Requests: rate limit excedido
- 400 Bad Request: prompt inválido o audio corrupto
- 500 Internal Server Error: error temporal de Google
- Network errors: timeout o conexión perdida

**Estrategia de retry**:
- Retry automático con exponential backoff
- Máximo 3 intentos por request
- Delay: 1s, 2s, 4s entre reintentos
- Logging de todos los errores para debugging

**Fallbacks**:
- Si Gemini falla, guardar job como "failed" con error message
- Usuario recibe notificación: "Procesamiento falló - reintentar"
- Botón manual de reintento en UI
- Opción de procesamiento manual como último recurso

---

## 5. Criterios de éxito y validación

### 5.1 Alta precisión en automatización y extracción

**Métricas de precisión requeridas**:
- Extracción correcta de nombre: **>90%**
- Extracción correcta de email: **>95%**
- Extracción correcta de empresa: **>85%**
- Identificación de deal: **>85%**
- Monto monetario: **>90%**
- Sentimiento: **>80%**
- Próximos pasos relevantes: **>75%**
- Fechas: **>85%**

**Dataset de validación**:
- 50 audios de llamadas reales (5-15 min cada uno)
- 50 emails diversos (prospección, seguimiento, cierre)
- 20 mensajes de WhatsApp con notas de voz
- Etiquetado manual de ground truth

**Método de evaluación**:
- Comparación automática campo por campo
- Cálculo de precision, recall, F1-score
- Revisión manual de casos ambiguos
- Iteración de prompts hasta alcanzar métricas

### 5.2 Flujo claro desde comunicación hasta CRM

**Demostración end-to-end obligatoria**:

**Punto A - Entrada original**:
- Audio de llamada de 5 minutos reproducible
- Email real visible en Gmail
- Mensaje de WhatsApp con timestamp

**Punto B - Procesamiento visible**:
- Job creado en base de datos con estado "pending"
- Progress bar o spinner en frontend
- Tiempo de procesamiento medido en segundos
- Logs de llamada a Gemini API accesibles

**Punto C - Resultado en CRM**:
- Contacto aparece en listado con badge "Nuevo"
- Deal creado con monto correcto en pipeline
- Actividad de tipo "call"/"email" con resumen
- Tareas generadas en lista de pendientes
- Transcripción completa disponible

**Visualización del flujo en demo**:
- Split screen: audio/email original + CRM vacío
- Animation de procesamiento en centro
- Reveal de CRM actualizado con highlighting de campos nuevos
- Timeline mostrando flujo temporal completo

### 5.3 Prototipo funcional demo-ready

**Requisitos mínimos para demo**:
1. ✅ Subir audio → procesamiento → CRM actualizado automáticamente
2. ✅ Email real procesado vía webhook funcionando
3. ✅ WhatsApp webhook recibiendo mensajes (simulado o real)
4. ✅ Búsqueda semántica respondiendo 5+ tipos de preguntas
5. ✅ Dashboard mostrando contactos, deals, actividades
6. ✅ Todo el flujo sin errores críticos ni crashes

**Video demo de 3-5 minutos**:

**Minuto 1**: Introducción del problema + solución
**Minuto 2**: Demo de voice-to-CRM en vivo
**Minuto 3**: Demo de email automation + actualización automática
**Minuto 4**: Demo de búsqueda inteligente con insights
**Minuto 5**: Conclusión con impacto medido (tiempo ahorrado)

**Datos realistas para demo**:
- 10 contactos con nombres ficticios pero contexto real
- 5 deals en diferentes etapas con montos variados
- 20 actividades históricas con transcripciones
- 10 tareas generadas automáticamente
- Búsquedas que devuelven resultados relevantes

### 5.4 Usabilidad y reducción de trabajo manual

**KPIs cuantificables**:

**Tiempo ahorrado**:
- CRM tradicional: 5 minutos por actualización manual
- Zero-Click CRM: <30 segundos (solo subir audio si aplica)
- **Ahorro: 90%+ del tiempo**
- Proyección: **30+ horas/mes ahorradas por usuario**

**Reducción de clicks**:
- CRM tradicional: 20-30 clicks por actualización
- Zero-Click CRM: 0-2 clicks máximo
- **Reducción: >90% de interacciones**

**Completitud de datos**:
- CRM tradicional: 40-50% de campos completos
- Zero-Click CRM: >90% de campos completos
- **Mejora: +80% más información**

**Adopción esperada**:
- Meta: >80% uso diario activo
- Time-to-value: usuario ve beneficio en <5 minutos
- NPS target: >40

***

## 6. Roadmap de implementación (5 días)

### Día 1: Setup + Integración básica con Gemini
- Configuración de proyecto Node.js + Express
- Instalación de SDK `@google/generative-ai`
- Setup de Supabase: schema de base de datos completo
- Autenticación con Supabase Auth
- Primera llamada exitosa a Gemini API (texto simple)
- Endpoints CRUD básicos de contactos
- Testing: texto → Gemini → respuesta estructurada

### Día 2: Voice-to-CRM + Auto-populating
- Implementación de upload de audio en backend
- Procesamiento de audio con Gemini multimodal
- Schema estructurado para extracción de CRM
- Sistema de jobs asíncronos en Supabase
- Lógica de upsert de contactos automático
- Testing con 5 audios reales: validar precisión >85%
- Refinamiento de prompts según resultados

### Día 3: Email automation + Data Freshness
- OAuth flow para Gmail
- Webhook endpoint para notificaciones de Gmail
- Procesamiento automático de emails con Gemini
- Integración con WhatsApp webhook (setup básico)
- Testing end-to-end: email real → procesamiento → CRM
- Validación de actualización automática de "última interacción"

### Día 4: AI Search + Insights + Frontend
- Búsqueda semántica con contexto de CRM
- Búsqueda por voz (transcripción + query)
- Generación de insights: deals en riesgo
- Frontend con Next.js: dashboard principal
- Componente de upload de audio con progress
- Barra de búsqueda conversacional
- Integración de Supabase Realtime

### Día 5: Pulido + Demo final
- Manejo de errores y retry logic
- Estados de loading y notificaciones
- Testing completo de todos los flujos
- Preparación de datos de demo realistas
- Grabación de video demo de 3-5 minutos
- Deploy a producción
- Documentación y slides

***

## 7. Métricas de éxito del MVP

**Técnicas**:
- ✅ Precisión de extracción con Gemini: >85%
- ✅ Tiempo de procesamiento: <60 seg (audio 15 min)
- ✅ Búsqueda semántica: <3 seg respuesta
- ✅ Uptime durante demo: 100%

**Producto**:
- ✅ Reducción tiempo manual: >70%
- ✅ Completitud de datos: >90%
- ✅ Usuario completa flujo: <60 seg sin ayuda
- ✅ Demo funciona sin errores

**Validación de "Zero-Click"**:
- ✅ Email procesado automáticamente (0 clicks)
- ✅ Audio requiere máximo 2 clicks (subir + procesar)
- ✅ 90%+ de actualizaciones de CRM sin entrada manual
- ✅ Búsqueda responde en lenguaje natural sin navegación
