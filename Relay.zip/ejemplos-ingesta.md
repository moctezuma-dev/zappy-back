# Ejemplos de Datos Mock para Ingesta

Este archivo contiene ejemplos de datos mock para probar los endpoints de ingesta.

## ⚡ Generación Automática de Datos Mock

**IMPORTANTE**: Los endpoints de ingesta ahora generan datos mock automáticamente si no se envía body o si se envía `{ "generate": true }`.

### Uso Simple (Generación Automática)

```bash
# Email - Genera datos mock automáticamente
curl -X POST http://localhost:4000/api/ingest/email

# Slack - Genera datos mock automáticamente
curl -X POST http://localhost:4000/api/ingest/slack

# WhatsApp - Genera datos mock automáticamente
curl -X POST http://localhost:4000/api/ingest/whatsapp
```

### Flujo Automático Completo

1. **Llamas al endpoint** sin body → Se generan datos mock automáticamente
2. **Se normalizan** los datos a la estructura de `interactions`
3. **Se insertan** en Supabase (tabla `interactions`)
4. **Los watchers detectan** el INSERT automáticamente
5. **Se dispara el análisis** automáticamente (`analyzeInteraction`)
6. **Gemini analiza** el texto (si está configurado) y extrae:
   - Requirements
   - KPIs
   - Budget
   - Next steps
   - Sentiment
   - Urgency
   - Topics
7. **Se actualiza** la interacción con los datos extraídos
8. **Se generan work_items** automáticamente desde `next_steps`
9. **Se actualiza** el contacto con sentimiento y fecha

---

## Ejemplos Manuales (Opcional)

Si prefieres enviar datos manualmente, aquí tienes ejemplos:

## POST /api/ingest/email

```json
{
  "from": "Juan Pérez <juan.perez@techsmart.com>",
  "to": "ventas@miempresa.com",
  "subject": "Cotización para proyecto de automatización",
  "body": "Hola equipo,\n\nEstamos interesados en una solución de automatización para nuestro departamento de logística. Necesitamos:\n\n- Integración con nuestro sistema ERP actual\n- Dashboard de seguimiento en tiempo real\n- Capacidad para procesar 10,000 órdenes diarias\n\nNuestro presupuesto es de aproximadamente $50,000 USD.\n\n¿Podrían enviarnos una propuesta detallada antes del 25 de enero?\n\nSaludos,\nJuan Pérez\nGerente de Operaciones\nTechSmart",
  "date": "2025-01-15T10:30:00Z",
  "company": "TechSmart",
  "attachments": [],
  "metadata": {}
}
```

## Alertas

```bash
curl "http://localhost:4000/api/alerts?status=open&severity=high"
```

```bash
curl -X POST http://localhost:4000/api/alerts/<uuid>/resolve
```

## Contextos IA

```bash
curl "http://localhost:4000/api/ai/contexts?type=interaction&companyId=<uuid>&limit=10"
```

```bash
curl -X DELETE http://localhost:4000/api/ai/contexts/<uuid>
```

## Tendencias (Dashboard)

```bash
curl "http://localhost:4000/api/crm/insights/trends?companyId=<uuid>&days=30"
```

## Insights Accionables

```bash
curl "http://localhost:4000/api/crm/insights/actionable?companyId=<uuid>"
```

## Chat Avanzado con Herramientas

```bash
curl -X POST http://localhost:4000/api/chat \
  -H "Content-Type: application/json" \
  -d '{
    "question": "¿Qué debo atender con TechSmart esta semana?",
    "companyId": "<uuid>",
    "tools": ["alerts", "risk_contacts", "timeline"]
  }'
```

## Chat con Acción (crear work item)

```bash
curl -X POST http://localhost:4000/api/chat \
  -H "Content-Type: application/json" \
  -d '{
    "question": "Programa un seguimiento el lunes",
    "companyId": "<uuid>",
    "action": {
      "type": "create_work_item",
      "payload": {
        "title": "Seguimiento TechSmart",
        "dueDate": "2025-01-20T15:00:00Z"
      }
    }
  }'
```

## Knowledge Base

```bash
curl -X POST http://localhost:4000/api/knowledge \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Caso de éxito 2024",
    "content": "Resumen del proyecto de modernización con TechSmart...",
    "companyId": "<uuid opcional>",
    "metadata": { "tipo": "caso" }
  }'
```

```bash
curl -X POST http://localhost:4000/api/knowledge/upload \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Notas de onboarding",
    "fileBase64": "<BASE64_DE_TXT>",
    "chunkSize": 1500
  }'
```

```bash
curl -X POST http://localhost:4000/api/knowledge/search \
  -H "Content-Type: application/json" \
  -d '{
    "query": "integración ERP",
    "companyId": "<uuid opcional>",
    "limit": 5
  }'
```

## Knowledge cleanup

```bash
curl "http://localhost:4000/api/knowledge?companyId=<uuid>&limit=10"
```

```bash
curl -X DELETE http://localhost:4000/api/knowledge/<uuid>"
```

## POST /api/ingest/slack

```json
{
  "user": {
    "name": "maria.garcia",
    "real_name": "María García",
    "email": "maria.garcia@saludexpress.com"
  },
  "channel": {
    "name": "ventas"
  },
  "text": "Hola equipo! 👋\n\nTenemos una nueva oportunidad con SaludExpress. Necesitan:\n- Implementación de sistema de gestión hospitalaria\n- Presupuesto: $120,000 USD\n- Fecha límite: 30 de enero\n- Requisitos: Certificación ISO 27001, soporte 24/7\n\nPróximos pasos:\n1. Agendar demo técnica para el 20 de enero\n2. Preparar propuesta comercial\n3. Revisar requisitos de compliance\n\n¿Alguien puede tomar la lead?",
  "ts": "1705320600.123456",
  "thread_ts": null,
  "company": "SaludExpress",
  "attachments": [],
  "metadata": {}
}
```

## POST /api/ingest/whatsapp

```json
{
  "from": "+521234567890",
  "to": "+529876543210",
  "message": "Hola! Me interesa el producto que vi en su página web. Necesito información sobre:\n\n- Precios y planes disponibles\n- Tiempo de implementación\n- Soporte técnico incluido\n\nMi empresa es ModaFutura y estamos buscando una solución para gestionar nuestro inventario.\n\n¿Podríamos agendar una llamada esta semana? Preferiblemente jueves o viernes por la tarde.\n\nGracias!",
  "timestamp": "2025-01-15T14:20:00Z",
  "contactName": "Ana López",
  "email": "ana.lopez@modafutura.com",
  "company": "ModaFutura",
  "media": null,
  "metadata": {}
}
```

## Ejemplo con Urgencia Alta

```json
{
  "from": "Roberto Sánchez <roberto.sanchez@energiaverde.com>",
  "to": "soporte@miempresa.com",
  "subject": "URGENTE: Problema crítico en producción",
  "body": "URGENTE: Tenemos un problema crítico en nuestro sistema de producción que está afectando nuestras operaciones.\n\nNecesitamos soporte inmediato:\n- El sistema está caído desde hace 2 horas\n- Estamos perdiendo $5,000 USD por hora\n- Necesitamos solución antes de las 6 PM hoy\n\nPor favor, contacten a nuestro equipo técnico lo antes posible.\n\nRoberto Sánchez\nDirector de IT\nEnergía Verde",
  "date": "2025-01-15T15:00:00Z",
  "company": "Energía Verde",
  "attachments": [],
  "metadata": {
    "priority": "critical"
  }
}
```

## Ejemplo con Propuesta Comercial

```json
{
  "from": "Laura Jiménez <laura.jimenez@finanzasnext.com>",
  "to": "comercial@miempresa.com",
  "subject": "Propuesta de colaboración - Proyecto Q1 2025",
  "body": "Estimado equipo,\n\nNos gustaría explorar una colaboración para nuestro proyecto de transformación digital en Q1 2025.\n\nDetalles del proyecto:\n- Presupuesto: $200,000 USD\n- Duración: 6 meses\n- KPIs objetivo: Reducción de costos operativos en 30%, mejora en tiempo de respuesta del 50%\n- Requisitos: Equipo certificado, metodología ágil, reportes semanales\n\nPróximos pasos:\n1. Reunión de kickoff: 22 de enero\n2. Presentación de propuesta técnica: 25 de enero\n3. Decisión final: 1 de febrero\n\nEsperamos su respuesta.\n\nSaludos cordiales,\nLaura Jiménez\nAnalista Senior\nFinanzas Next",
  "date": "2025-01-15T11:00:00Z",
  "company": "Finanzas Next",
  "attachments": [],
  "metadata": {}
}
```

## Cómo Probar

### Opción 1: Generación Automática (Recomendado)

```bash
# Email - Genera datos mock automáticamente
curl -X POST http://localhost:4000/api/ingest/email

# Slack - Genera datos mock automáticamente
curl -X POST http://localhost:4000/api/ingest/slack

# WhatsApp - Genera datos mock automáticamente
curl -X POST http://localhost:4000/api/ingest/whatsapp
```

### Opción 2: Enviar Datos Manualmente

```bash
# Email
curl -X POST http://localhost:4000/api/ingest/email \
  -H "Content-Type: application/json" \
  -d '{
    "from": "Juan Pérez <juan.perez@techsmart.com>",
    "to": "ventas@miempresa.com",
    "subject": "Cotización para proyecto",
    "body": "Hola, necesito una cotización para un proyecto de automatización. Presupuesto: $50,000 USD. Fecha límite: 25 de enero.",
    "date": "2025-01-15T10:30:00Z",
    "company": "TechSmart"
  }'

# Slack
curl -X POST http://localhost:4000/api/ingest/slack \
  -H "Content-Type: application/json" \
  -d '{
    "user": {"name": "maria.garcia", "real_name": "María García"},
    "channel": {"name": "ventas"},
    "text": "Nueva oportunidad con SaludExpress. Presupuesto: $120,000 USD. Próximos pasos: Demo el 20 de enero, propuesta comercial.",
    "ts": "1705320600.123456"
  }'

# WhatsApp
curl -X POST http://localhost:4000/api/ingest/whatsapp \
  -H "Content-Type: application/json" \
  -d '{
    "from": "+521234567890",
    "to": "+529876543210",
    "message": "Hola! Me interesa el producto. Necesito información sobre precios y planes. ¿Podríamos agendar una llamada esta semana?",
    "timestamp": "2025-01-15T14:20:00Z",
    "contactName": "Ana López",
    "company": "ModaFutura"
  }'
```

## Flujo Automático

1. **Ingesta**: Envías datos mock al endpoint `/api/ingest/*`
2. **Normalización**: El servicio normaliza los datos a la estructura de `interactions`
3. **Inserción**: Se inserta en la tabla `interactions` de Supabase
4. **Detección Automática**: Los watchers en tiempo real detectan el INSERT
5. **Análisis Automático**: Se dispara `analyzeInteraction()` automáticamente
6. **Análisis con Gemini**: Si está configurado, Gemini analiza el texto y extrae:
   - Requirements
   - KPIs
   - Budget
   - Next steps
   - Sentiment
   - Urgency
   - Topics
7. **Actualización**: Se actualiza la interacción con los datos extraídos
8. **Generación de Work Items**: Se crean `work_items` automáticamente desde `next_steps`
9. **Actualización de Contacto**: Se actualiza el contacto con el sentimiento y fecha
10. **Indexación IA**: Se guarda un contexto semántico en `ai_contexts` para búsqueda y chat

## Verificar Resultados

Después de enviar datos mock, puedes verificar:

1. **Interacciones**: `SELECT * FROM interactions ORDER BY created_at DESC LIMIT 5;`
2. **Análisis**: `SELECT * FROM jobs WHERE type = 'analysis' ORDER BY created_at DESC LIMIT 5;`
3. **Work Items Generados**: `SELECT * FROM work_items WHERE data->>'auto_generated' = 'true' ORDER BY created_at DESC;`
4. **Contactos Actualizados**: `SELECT * FROM contacts WHERE updated_at > NOW() - INTERVAL '1 hour';`
5. **Contextos IA**: `SELECT * FROM ai_contexts ORDER BY updated_at DESC LIMIT 10;`

---

## Búsqueda Semántica

```bash
curl -X POST http://localhost:4000/api/search/query \
  -H "Content-Type: application/json" \
  -d '{
    "query": "pendientes críticos con TechSmart",
    "companyId": "<UUID opcional>",
    "type": "work_item",
    "limit": 5
  }'
```

La respuesta incluye `text`, `metadata` y `similarity` para cada contexto encontrado.

## Chat Corporativo

```bash
curl -X POST http://localhost:4000/api/chat \
  -H "Content-Type: application/json" \
  -d '{
    "question": "Dame el estado actual de TechSmart",
    "companyId": "<UUID opcional>",
    "topK": 5
  }'
```

Respuesta ejemplo:
```json
{
  "ok": true,
  "sessionId": "uuid",
  "answer": "Actualmente TechSmart solicitó integraciones en la última reunión...",
  "sources": [
    {
      "id": "context-uuid",
      "type": "interaction",
      "similarity": 0.82,
      "metadata": { "channel": "email", "next_steps": [...] }
    }
  ]
}
```

Para continuar la conversación reutiliza `sessionId`:
```bash
curl -X POST http://localhost:4000/api/chat \
  -H "Content-Type: application/json" \
  -d '{
    "sessionId": "uuid",
    "question": "¿Hay riesgos pendientes?",
    "topK": 3
  }'
```

## Dashboard / Insights

```bash
curl "http://localhost:4000/api/crm/insights/summary?limit=5"
```

Parámetros opcionales:
- `companyId=<uuid>` filtra por empresa
- `limit=5` controla el número de registros en listas (top deals, work items, interacciones)

Respuesta resumida:
```json
{
  "ok": true,
  "summary": {
    "interactions": { "total": 42, "last7Days": 6, "last30Days": 18, "uniqueContacts": 12 },
    "workItems": { "total": 15, "open": 11, "overdue": 2, "dueNext7Days": 3 },
    "freshData": { "total": 9, "last30Days": 4 },
    "contacts": { "total": 25, "updatedLast30Days": 8 },
    "pipeline": { "totalBudget": 185000, "avgBudget": 30833.33 }
  },
  "workItemsStatus": [
    { "status": "pending", "total": 6 },
    { "status": "in_progress", "total": 3 }
  ],
  "sentiment": [
    { "sentiment": "positive", "total": 9 },
    { "sentiment": "neutral", "total": 10 }
  ],
  "topDeals": [
    { "id": "uuid", "budget": 50000, "company": { "name": "TechSmart" } }
  ],
  "upcomingWorkItems": [
    { "id": "uuid", "title": "Enviar propuesta", "due_date": "2025-01-20T12:00:00Z" }
  ],
  "recentInteractions": [
    { "id": "uuid", "channel": "email", "occurred_at": "2025-01-15T10:30:00Z" }
  ]
}
```

## Timeline Unificado

```bash
curl "http://localhost:4000/api/crm/timeline?companyId=<uuid>&limit=30"
```

Respuesta:
```json
{
  "ok": true,
  "entries": [
    {
      "type": "interaction",
      "id": "uuid",
      "occurredAt": "2025-01-17T16:20:00Z",
      "channel": "email",
      "summary": "Asunto: Cotización...",
      "company": { "id": "...", "name": "TechSmart" },
      "contact": { "id": "...", "name": "Juan Pérez" }
    },
    {
      "type": "work_item",
      "id": "uuid",
      "title": "Preparar demo técnica",
      "status": "in_progress",
      "priority": "high",
      "dueDate": "2025-01-20T12:00:00Z",
      "assignee": { "id": "...", "name": "María García" }
    },
    {
      "type": "fresh_data",
      "id": "uuid",
      "topic": "Transformación digital",
      "title": "TechSmart gana premio de innovación",
      "source": "Google News",
      "detectedAt": "2025-01-18T09:10:00Z"
    }
  ],
  "total": 27
}
```

## Company Overview

```bash
curl "http://localhost:4000/api/crm/companies/<uuid>/overview?interactionsLimit=5&workItemsLimit=5"
```

Incluye:
- Información de la empresa
- Contactos recientes
- Work items abiertos (con prioridad y responsables)
- Interacciones más recientes (mail, slack, zoom, etc.)
- Señales externas (`fresh_data`)
- Métricas de pipeline (suma y promedio de presupuesto)
- Sentiment y estado de work items

Respuesta ejemplo:
```json
{
  "ok": true,
  "company": {
    "id": "uuid",
    "name": "TechSmart",
    "industry": "Technology"
  },
  "contacts": [
    { "id": "uuid", "name": "Juan Pérez", "email": "juan@techsmart.com", "sentiment": "positive" }
  ],
  "workItems": [
    { "id": "uuid", "title": "Preparar demo técnica", "status": "in_progress", "due_date": "2025-01-20T12:00:00Z" }
  ],
  "interactions": [
    { "id": "uuid", "occurred_at": "2025-01-17T16:20:00Z", "channel": "email", "budget": 50000 }
  ],
  "pipeline": {
    "totalBudget": 185000,
    "avgBudget": 30833.33,
    "dealsCount": 6
  }
}
```

## Contact Overview

```bash
curl "http://localhost:4000/api/crm/contacts/<uuid>/overview?interactionsLimit=5&workItemsLimit=5"
```

Incluye:
- Datos del contacto (rol, correo, sentimiento, empresa)
- Interacciones recientes (canal, presupuesto, requisitos)
- Work items vinculados como responsable o dueño
- Señales relevantes de la empresa del contacto
- Pipeline asociado (suma de budgets en interacciones)

Respuesta ejemplo:
```json
{
  "ok": true,
  "contact": {
    "id": "uuid",
    "name": "Juan Pérez",
    "email": "juan@techsmart.com",
    "sentiment": "positive",
    "company": { "id": "uuid", "name": "TechSmart" }
  },
  "interactions": [
    { "id": "uuid", "occurred_at": "2025-01-17T16:20:00Z", "channel": "email", "budget": 50000 }
  ],
  "workItems": [
    { "id": "uuid", "title": "Preparar demo técnica", "status": "in_progress", "priority": "high", "due_date": "2025-01-20T12:00:00Z" }
  ],
  "pipeline": {
    "totalBudget": 85000,
    "dealsCount": 2
  }
}
```

## Notas Manuales

```bash
curl -X POST http://localhost:4000/api/notes \
  -H "Content-Type: application/json" \
  -d '{
    "companyId": "<uuid opcional>",
    "contactId": "<uuid opcional>",
    "author": "María García",
    "channel": "note",
    "text": "Llamada rápida. Quieren propuesta final el lunes con sección de KPIs.",
    "occurredAt": "2025-01-18T10:30:00Z",
    "metadata": {
      "origin": "phone",
      "importance": "high"
    }
  }'
```

Esto inserta una interacción tipo nota en Supabase y la indexa en `ai_contexts` para que el chat y la búsqueda semántica la utilicen de inmediato.

